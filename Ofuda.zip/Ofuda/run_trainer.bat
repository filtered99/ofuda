@echo off
setlocal

echo [Ofuda] Initializing Workspace Setup...
if not exist "weights" mkdir weights
if not exist "training_data" mkdir training_data

if not exist "training_data\corpus.txt" (
    echo hello world. ofuda learns c++ transformers with cuda. > "training_data\corpus.txt"
)

echo [Ofuda] Building C++ Project with CUDA Stubs...
if not exist build mkdir build
cd build
cmake ..
cmake --build . --config Release

echo [Ofuda] Running C++ Engine (with optional --cuda flag)...
if exist Release\ofuda.exe (
    Release\ofuda.exe --cuda
) else if exist ofuda.exe (
    ofuda.exe --cuda
) else (
    cd ..
    python train.py
)

endlocal
